﻿using Microsoft.EntityFrameworkCore;
using ToDo.DATA.Dtos;
using ToDo.DATA.Models;

namespace ToDo.DATA.Services;

public class TaskItemService
{
    private readonly ApplicationDbContext _context;

    public TaskItemService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<TaskItemDto>> GetAllForUserAsync(int userId)
    {
        return await _context.TaskItems
            .Where(t => t.UserId == userId)
            .Select(t => new TaskItemDto
            {
                Id = t.Id,
                Title = t.Title,
                Description = t.Description,
                Status = t.Status,
                DueDate = t.DueDate,
                CreatedAt = t.CreatedAt,
                UpdatedAt = t.UpdatedAt,
                UserId = t.UserId
            })
            .ToListAsync();
    }

    public async Task<TaskItemDto?> GetByIdAsync(int id)
    {
        var task = await _context.TaskItems.FindAsync(id);
        if (task == null) return null;

        return new TaskItemDto
        {
            Id = task.Id,
            Title = task.Title,
            Description = task.Description,
            Status = task.Status,
            DueDate = task.DueDate,
            CreatedAt = task.CreatedAt,
            UpdatedAt = task.UpdatedAt,
            UserId = task.UserId
        };
    }

    public async Task<TaskItemDto> CreateAsync(CreateTaskItemDto dto)
    {
        var now = DateTime.UtcNow;
        var task = new TaskItem
        {
            Title = dto.Title,
            Description = dto.Description,
            Status = dto.Status,
            DueDate = dto.DueDate,
            CreatedAt = now,
            UpdatedAt = now,
            UserId = dto.UserId
        };

        _context.TaskItems.Add(task);
        await _context.SaveChangesAsync();

        return new TaskItemDto
        {
            Id = task.Id,
            Title = task.Title,
            Description = task.Description,
            Status = task.Status,
            DueDate = task.DueDate,
            CreatedAt = task.CreatedAt,
            UpdatedAt = task.UpdatedAt,
            UserId = task.UserId
        };
    }
}