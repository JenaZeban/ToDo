﻿using Microsoft.EntityFrameworkCore;
using ToDo.DATA.Models;

namespace ToDo.DATA;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
    
    public DbSet<User> Users { get; set; }
    public DbSet<TaskItem> TaskItems { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("users");  // используем существующую таблицу users

            entity.HasMany(u => u.TaskItems)
                .WithOne(t => t.User)
                .HasForeignKey(t => t.UserId);
        });

        modelBuilder.Entity<TaskItem>(entity =>
        {
            entity.ToTable("task_items");  // используем существующую таблицу task_items
        });

        base.OnModelCreating(modelBuilder);
    }
}