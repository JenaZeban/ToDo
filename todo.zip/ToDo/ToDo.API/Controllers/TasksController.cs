﻿using Microsoft.AspNetCore.Mvc;
using ToDo.DATA.Dtos;
using ToDo.DATA.Services;

namespace ToDo.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TasksController : ControllerBase
{
    private readonly TaskItemService _taskService;

    public TasksController(TaskItemService taskService)
    {
        _taskService = taskService;
    }

    [HttpGet("user/{userId}")]
    public async Task<IActionResult> GetAllForUser(int userId)
    {
        var tasks = await _taskService.GetAllForUserAsync(userId);
        return Ok(tasks);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        var task = await _taskService.GetByIdAsync(id);
        return task is not null ? Ok(task) : NotFound();
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateTaskItemDto dto)
    {
        var created = await _taskService.CreateAsync(dto);
        return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
    }
}